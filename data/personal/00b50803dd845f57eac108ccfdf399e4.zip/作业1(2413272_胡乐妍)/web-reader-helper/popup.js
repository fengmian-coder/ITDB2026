// =============================
// popup.js
// =============================


// 默认设置
const defaultSettings = {

    darkMode: false,

    hideImages: false,

    readingMode: false,

    zoom: 100
};


// 获取控件
const darkMode =
    document.getElementById("darkMode");

const hideImages =
    document.getElementById("hideImages");

const readingMode =
    document.getElementById("readingMode");

const zoomRange =
    document.getElementById("zoomRange");

const zoomValue =
    document.getElementById("zoomValue");

const resetBtn =
    document.getElementById("resetBtn");


// -----------------------------
// 获取当前设置
// -----------------------------

function getCurrentSettings() {

    return {

        darkMode:
            darkMode.checked,

        hideImages:
            hideImages.checked,

        readingMode:
            readingMode.checked,

        zoom:
            Number(zoomRange.value)

    };
}


// -----------------------------
// 保存设置
// -----------------------------

function saveSettings() {

    const settings =
        getCurrentSettings();

    chrome.storage.local.set({

        readerSettings:
            settings

    });
}


// -----------------------------
// 页面打开时恢复设置
// -----------------------------

chrome.storage.local.get(
    ["readerSettings"],

    function (result) {

        const settings =
            Object.assign(
                {},
                defaultSettings,
                result.readerSettings || {}
            );


        darkMode.checked =
            settings.darkMode;

        hideImages.checked =
            settings.hideImages;

        readingMode.checked =
            settings.readingMode;

        zoomRange.value =
            settings.zoom;

        zoomValue.textContent =
            settings.zoom;
    }
);


// -----------------------------
// 夜间模式
// -----------------------------

darkMode.addEventListener(
    "change",
    saveSettings
);


// -----------------------------
// 图片隐藏
// -----------------------------

hideImages.addEventListener(
    "change",
    saveSettings
);


// -----------------------------
// 阅读模式
// -----------------------------

readingMode.addEventListener(
    "change",
    saveSettings
);


// -----------------------------
// 页面缩放
// -----------------------------

zoomRange.addEventListener(
    "input",

    function () {

        zoomValue.textContent =
            zoomRange.value;

        saveSettings();
    }
);


// -----------------------------
// 恢复默认设置
// -----------------------------

resetBtn.addEventListener(
    "click",

    function () {

        darkMode.checked =
            false;

        hideImages.checked =
            false;

        readingMode.checked =
            false;

        zoomRange.value =
            100;

        zoomValue.textContent =
            100;

        saveSettings();
    }
);


// -----------------------------
// 获取当前网页统计
// -----------------------------

chrome.tabs.query(
    {
        active: true,
        currentWindow: true
    },

    function (tabs) {

        if (!tabs[0]) {
            return;
        }

        chrome.tabs.sendMessage(

            tabs[0].id,

            {
                action: "getStats"
            },

            function (response) {

                if (
                    chrome.runtime.lastError ||
                    !response
                ) {

                    return;
                }


                document.getElementById(
                    "charCount"
                ).textContent =
                    response.charCount;


                document.getElementById(
                    "imageCount"
                ).textContent =
                    response.imageCount;


                document.getElementById(
                    "linkCount"
                ).textContent =
                    response.linkCount;


                document.getElementById(
                    "readingTime"
                ).textContent =
                    response.readingTime;
            }
        );
    }
);