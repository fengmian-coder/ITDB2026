// =============================
// 网页阅读增强助手 - content.js
// =============================


// 默认设置
const defaultSettings = {

    darkMode: false,

    hideImages: false,

    readingMode: false,

    zoom: 100
};


// -----------------------------
// 添加插件所需 CSS
// -----------------------------

function addPluginStyle() {

    if (document.getElementById("web-reader-helper-style")) {
        return;
    }

    const style = document.createElement("style");

    style.id = "web-reader-helper-style";

    style.textContent = `

        /* 夜间模式 */
        html.web-helper-dark {
            filter:
                invert(0.88)
                hue-rotate(180deg);

            background-color: #111 !important;
        }


        /* 防止图片颜色被反转 */
        html.web-helper-dark img,
        html.web-helper-dark video,
        html.web-helper-dark canvas {
            filter:
                invert(1)
                hue-rotate(180deg);
        }


        /* 隐藏图片 */
        html.web-helper-hide-images img,
        html.web-helper-hide-images picture {
            visibility: hidden !important;
        }


        /* 阅读模式 */
        html.web-helper-reading body {

            max-width: 900px !important;

            margin-left: auto !important;

            margin-right: auto !important;

            padding-left: 30px !important;

            padding-right: 30px !important;

            line-height: 1.8 !important;
        }


        html.web-helper-reading p {

            line-height: 1.8 !important;

        }

    `;

    document.head.appendChild(style);
}


// -----------------------------
// 应用设置
// -----------------------------

function applySettings(settings) {

    addPluginStyle();

    const html = document.documentElement;


    // 夜间模式
    if (settings.darkMode) {

        html.classList.add(
            "web-helper-dark"
        );

    } else {

        html.classList.remove(
            "web-helper-dark"
        );
    }


    // 隐藏图片
    if (settings.hideImages) {

        html.classList.add(
            "web-helper-hide-images"
        );

    } else {

        html.classList.remove(
            "web-helper-hide-images"
        );
    }


    // 阅读模式
    if (settings.readingMode) {

        html.classList.add(
            "web-helper-reading"
        );

    } else {

        html.classList.remove(
            "web-helper-reading"
        );
    }


    // 页面缩放
    if (document.body) {

        document.body.style.zoom =
            settings.zoom + "%";
    }
}


// -----------------------------
// 页面加载后读取设置
// -----------------------------

chrome.storage.local.get(
    ["readerSettings"],

    function (result) {

        const settings = Object.assign(
            {},
            defaultSettings,
            result.readerSettings || {}
        );

        applySettings(settings);
    }
);


// -----------------------------
// 监听设置变化
// -----------------------------

chrome.storage.onChanged.addListener(
    function (changes, areaName) {

        if (
            areaName === "local" &&
            changes.readerSettings
        ) {

            const newSettings =
                changes.readerSettings.newValue;

            applySettings(newSettings);
        }
    }
);


// -----------------------------
// 获取网页统计信息
// -----------------------------

function getPageStats() {

    const text =
        document.body
            ? document.body.innerText
            : "";

    // 去除空白字符
    const cleanText =
        text.replace(/\s+/g, "");

    const charCount =
        cleanText.length;

    const imageCount =
        document.querySelectorAll("img").length;

    const linkCount =
        document.querySelectorAll("a").length;


    // 假设平均每分钟阅读约 500 个字符
    const readingTime =
        Math.max(
            1,
            Math.ceil(charCount / 500)
        );


    return {

        charCount: charCount,

        imageCount: imageCount,

        linkCount: linkCount,

        readingTime: readingTime
    };
}


// -----------------------------
// 接收 popup 消息
// -----------------------------

chrome.runtime.onMessage.addListener(

    function (
        request,
        sender,
        sendResponse
    ) {

        if (request.action === "getStats") {

            sendResponse(
                getPageStats()
            );
        }

    }
);