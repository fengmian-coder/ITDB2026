import http from 'node:http';
import fs from 'node:fs';
const html = `<!doctype html><meta charset="utf-8"><title>请求与事件实验</title>
<script src="/jquery.js"></script>
<style>body{font:18px system-ui;max-width:900px;margin:60px auto;padding:20px;color:#173b32}button{font:inherit;margin:8px;padding:12px 20px}pre{white-space:pre-wrap;background:#eef4f1;padding:24px}#note{padding:20px;background:#e6f5eb}</style><h1>Web 请求与 jQuery 事件实验</h1><p>个人作业 1 · 张馨月</p><button id="get">GET 查询</button><button id="post">POST 提交</button>
<button id="toggle">展开说明</button><p id="note" hidden>这是 jQuery 事件触发后的内容。</p><pre id="result"></pre>
<script>
document.querySelector('#get').onclick = async () => result.textContent = await (await fetch('/api?team=MEX')).text();
document.querySelector('#post').onclick = async () => result.textContent = await (await fetch('/api',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nickname:'球迷',content:'期待下一场比赛'})})).text();
$('#toggle').on('click', function () {
  const visible = $('#note').prop('hidden');
  $('#note').prop('hidden', !visible);
  $(this).text(visible ? '收起说明' : '展开说明');
});
</script>`;
http.createServer(async (req,res)=>{
 const url = new URL(req.url,'http://127.0.0.1');
 if(url.pathname==='/jquery.js'){res.writeHead(200,{'Content-Type':'text/javascript'});return res.end(fs.readFileSync(new URL('./vendor/jquery-3.7.1.min.js',import.meta.url)));}
 if(url.pathname==='/prototype'){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});return res.end(fs.readFileSync(new URL('../作业2/原型.html',import.meta.url)));}
 if (url.pathname === '/') {res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'}); return res.end(html);}
 if(url.pathname !== '/api') {res.writeHead(404); return res.end();}
 let status=200, data;
 if(req.method==='GET') data={team:url.searchParams.get('team')};
 else if(req.method==='POST'){
   try{let body='';for await(const chunk of req)body+=chunk;const {nickname,content}=JSON.parse(body);status=201;data={nickname,content};}
   catch{status=400;data={error:'无效 JSON'};}
 }else{status=405;data={error:'方法不支持'};}
 res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});
 res.end(JSON.stringify(data));
}).listen(Number(process.env.D_LAB_PORT || 8765),'127.0.0.1');


