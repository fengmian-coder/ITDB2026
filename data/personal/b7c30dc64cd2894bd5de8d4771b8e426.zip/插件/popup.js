const title = document.querySelector('#title');
const url = document.querySelector('#url');
const copy = document.querySelector('#copy');
const status = document.querySelector('#status');
chrome.tabs.query({active:true,currentWindow:true}).then(([tab])=>{
  if (!tab?.url) { status.textContent='当前标签页没有可读网址。'; return; }
  title.textContent=tab.title || '未命名页面';
  url.textContent=tab.url;
  copy.disabled=false;
}).catch(()=>{status.textContent='读取标签页失败。';});
copy.addEventListener('click',async ()=>{
  try { await navigator.clipboard.writeText(title.textContent+'\n'+url.textContent);status.textContent='已复制'; }
  catch {status.textContent='复制失败，请手动选择文本。';}
});
