#### 第二次个人作业说明：

- AdminLTE-master

  后台模板

- conference-website-main

  前台模板

- CampusGo.rp

  使用Axure设计的页面文件

- 作业2(2413272_胡乐妍).pdf

  此次作业的实验报告