<?php
/**
 * Plugin Name: WCJ Reading Note
 * Description: 在观赛笔记页面插入资料复核提示，短代码为 [wcj_note]。
 * Version: 1.0.0
 * Author: 张馨月
 */
defined('ABSPATH') || exit;

add_shortcode('wcj_note', static function (): string {
    return '<aside class="wcj-reading-note" style="padding:16px;border-left:4px solid #123e32;background:#edf5f0">'
        . esc_html('观赛笔记提示：发布比赛分析前，请核对赛果、事件时间和资料来源。')
        . '</aside>';
});
