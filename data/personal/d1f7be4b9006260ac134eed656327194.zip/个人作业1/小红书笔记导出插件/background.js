chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'DOWNLOAD_MD') {
    chrome.downloads.download({
      url: message.url,
      filename: message.filename,
      saveAs: false
    });
  }
});