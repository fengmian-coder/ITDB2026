// ---------- 1. 提取笔记信息 ----------
function extractNoteData() {
  const titleEl = document.querySelector('#detail-title');
  const descEl = document.querySelector('#detail-desc .note-text');
  const authorEl = document.querySelector('.author-container .username');
  const dateEl = document.querySelector('.bottom-left .date');

  if (!titleEl || !descEl) {
    alert('未能识别笔记内容，请确认当前处于笔记详情页');
    return null;
  }

  const title = titleEl.innerText.trim();

  // 提取标签（.note-text 内部的 a.tag）
  const tagEls = descEl.querySelectorAll('a.tag');
  const tags = Array.from(tagEls).map(a => a.innerText.trim());

  // 提取纯正文：克隆一份 .note-text，把里面的标签 <a> 删掉，剩下的就是纯文字
  const descClone = descEl.cloneNode(true);
  descClone.querySelectorAll('a.tag').forEach(a => a.remove());
  const bodyText = descClone.innerText.trim();

  const author = authorEl ? authorEl.innerText.trim() : '未知作者';
  const dateInfo = dateEl ? dateEl.innerText.trim() : '';
  const url = window.location.href;

  return { title, bodyText, tags, author, dateInfo, url };
}

// ---------- 2. 组装成 Markdown ----------
function buildMarkdown(data) {
  let md = `# ${data.title}\n\n`;
  md += `**作者：** ${data.author}\n`;
  md += `**${data.dateInfo}**\n\n`;
  md += `${data.bodyText}\n\n`;
  if (data.tags.length > 0) {
    md += data.tags.map(t => t.startsWith('#') ? t : '#' + t).join(' ') + '\n\n';
  }
  md += `> 来源：${data.url}\n`;
  return md;
}

// ---------- 3. 导出逻辑：复制到剪贴板 + 下载文件 ----------
async function exportAsMarkdown() {
  const data = extractNoteData();
  if (!data) return;

  const markdown = buildMarkdown(data);

  // 复制到剪贴板
  try {
    await navigator.clipboard.writeText(markdown);
  } catch (err) {
    console.warn('剪贴板复制失败', err);
  }

  // 触发下载
  const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const safeTitle = data.title.replace(/[\\/:*?"<>|]/g, '').slice(0, 30) || 'note';

  chrome.runtime.sendMessage({
    type: 'DOWNLOAD_MD',
    url: url,
    filename: `${safeTitle}.md`
  });

  showToast('已导出并复制到剪贴板 ✓');
}

// ---------- 4. 简单提示条 ----------
function showToast(text) {
  const toast = document.createElement('div');
  toast.textContent = text;
  toast.style.cssText = `
    position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%);
    background: rgba(0,0,0,0.8); color: #fff; padding: 8px 16px;
    border-radius: 20px; z-index: 99999; font-size: 14px;
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2000);
}

// ---------- 5. 创建悬浮导出按钮 ----------
function createExportButton() {
  if (document.getElementById('md-export-btn')) return;

  const btn = document.createElement('button');
  btn.id = 'md-export-btn';
  btn.innerText = '导出 MD';
  btn.style.cssText = `
    position: fixed; right: 20px; bottom: 100px; z-index: 99999;
    background: #ff2442; color: #fff; border: none; border-radius: 28px;
    padding: 16px 28px; font-size: 18px; font-weight: 600; cursor: pointer;
    box-shadow: 0 4px 12px rgba(0,0,0,0.25);
  `;
  btn.addEventListener('click', exportAsMarkdown);
  document.body.appendChild(btn);
}

// ---------- 6. 监听页面变化，只在详情页弹窗打开时显示按钮 ----------
function checkAndToggleButton() {
  const isDetailOpen = document.querySelector('.note-detail-mask') !== null;
  const existingBtn = document.getElementById('md-export-btn');
  if (isDetailOpen && !existingBtn) {
    createExportButton();
  } else if (!isDetailOpen && existingBtn) {
    existingBtn.remove();
  }
}

const observer = new MutationObserver(checkAndToggleButton);
observer.observe(document.body, { childList: true, subtree: true });

checkAndToggleButton();