/* ============================================================
   COFF CAFE · 汀曼大师咖啡店点单页
   数据来源：游戏内经典轮换菜单 + 1.4 现售菜单
   ============================================================ */

const GROUPS = {
  all:       { cn: '全部',     en: 'ALL' },
  signature: { cn: '今日供应', en: 'TODAY' },
  blacktea:  { cn: '红茶拿提', en: 'BLACK TEA' },
  fruit:     { cn: '果泡拿提', en: 'FRUIT FOAM' },
  barley:    { cn: '麦草拿提', en: 'BARLEY' },
  pepper:    { cn: '胡椒拿提', en: 'PEPPER' },
  moonrock:  { cn: '月壤摩咔', en: 'MOONROCK' },
  bubble:    { cn: '空泡摩咔', en: 'MOCHA' }
};

const DAY_SHORT = { 1: 'MON', 2: 'TUE', 3: 'WED', 4: 'THU', 5: 'FRI', 6: 'SAT', 0: 'SUN' };
const DAY_CN = { 1: '周一', 2: '周二', 3: '周三', 4: '周四', 5: '周五', 6: '周六', 0: '周日' };

const MENU = [
  {
    id: 'tin-master', name: '汀曼特调', en: 'TIN MASTER SPECIAL',
    group: 'signature', accent: '#d7ff3f', liquid: '#d7ff3f', garnish: 'star',
    variant: '', era: 'now', battery: 80, price: 0, days: [],
    effect: '无额外掉落加成', scope: '纯电量恢复 · 正式绳匠 Lv.20 解锁',
    art: 'signature', code: 'TMS-80'
  },
  {
    id: 'espresso', name: '浓缩咖啡', en: 'ESPRESSO',
    group: 'signature', accent: '#ffb45c', liquid: '#a85b28', garnish: 'crema',
    variant: '', era: 'now', battery: 60, price: 0, days: [],
    effect: '全部掉落 +100%', scope: '实战模拟室 · 初始开放',
    art: 'espresso', code: 'ESP-60'
  },
  {
    id: 'black-tea', name: '红茶拿提', en: 'BLACK TEA LATTE',
    group: 'blacktea', accent: '#ffb23e', liquid: '#c9822f', garnish: 'leaf',
    variant: '', era: 'classic', battery: 60, price: 2500, days: [1, 4, 0],
    effect: '「强攻认证章」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'BTL-01'
  },
  {
    id: 'black-tea-mild', name: '红茶拿提（淡）', en: 'BLACK TEA LATTE · MILD',
    group: 'blacktea', accent: '#ffc970', liquid: '#d9a45f', garnish: 'leaf',
    variant: '淡', era: 'classic', battery: 60, price: 2500, days: [2, 5, 0],
    effect: '「击破认证章」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'BTL-02'
  },
  {
    id: 'black-tea-dark', name: '红茶拿提（浓）', en: 'BLACK TEA LATTE · DARK',
    group: 'blacktea', accent: '#e58a2f', liquid: '#8f4f1f', garnish: 'leaf',
    variant: '浓', era: 'classic', battery: 60, price: 2500, days: [2, 5, 0],
    effect: '「异常认证章」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'BTL-03'
  },
  {
    id: 'fruit-foam', name: '果泡拿提', en: 'FRUIT FOAM LATTE',
    group: 'fruit', accent: '#ff6b7a', liquid: '#d94a62', garnish: 'fruit',
    variant: '', era: 'classic', battery: 60, price: 2500, days: [3, 6, 0],
    effect: '「支援认证章」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'FFL-01'
  },
  {
    id: 'fruit-foam-mild', name: '果泡拿提（淡）', en: 'FRUIT FOAM LATTE · MILD',
    group: 'fruit', accent: '#ff9aa4', liquid: '#e8788a', garnish: 'fruit',
    variant: '淡', era: 'classic', battery: 60, price: 2500, days: [1, 4, 0],
    effect: '「防护认证章」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'FFL-02'
  },
  {
    id: 'barley', name: '麦草拿提', en: 'BARLEY LATTE',
    group: 'barley', accent: '#8be28b', liquid: '#5eaa62', garnish: 'grass',
    variant: '', era: 'classic', battery: 60, price: 2500, days: [3, 6, 0],
    effect: '「物理战术芯片」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'BLY-01'
  },
  {
    id: 'barley-mild', name: '麦草拿提（淡）', en: 'BARLEY LATTE · MILD',
    group: 'barley', accent: '#a8ee9e', liquid: '#7cc078', garnish: 'grass',
    variant: '淡', era: 'classic', battery: 60, price: 2500, days: [1, 4, 0],
    effect: '「引燃战术芯片」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'BLY-02'
  },
  {
    id: 'barley-dark', name: '麦草拿提（浓）', en: 'BARLEY LATTE · DARK',
    group: 'barley', accent: '#5fbd68', liquid: '#3f8546', garnish: 'grass',
    variant: '浓', era: 'classic', battery: 60, price: 2500, days: [2, 5, 0],
    effect: '「冰洁战术芯片」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'BLY-03'
  },
  {
    id: 'pepper', name: '胡椒拿提', en: 'PEPPER LATTE',
    group: 'pepper', accent: '#ff8b4a', liquid: '#c9653b', garnish: 'pepper',
    variant: '', era: 'classic', battery: 60, price: 2500, days: [3, 6, 0],
    effect: '「电击战术芯片」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'PPL-01'
  },
  {
    id: 'pepper-mild', name: '胡椒拿提（淡）', en: 'PEPPER LATTE · MILD',
    group: 'pepper', accent: '#ffad7a', liquid: '#dd8b60', garnish: 'pepper',
    variant: '淡', era: 'classic', battery: 60, price: 2500, days: [3, 6, 0],
    effect: '「以太战术芯片」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'PPL-02'
  },
  {
    id: 'moonrock', name: '月壤摩咔', en: 'MOONROCK MOCHACCINO',
    group: 'moonrock', accent: '#b8a7ff', liquid: '#7a68c9', garnish: 'moon',
    variant: '', era: 'classic', battery: 60, price: 2500, days: [1, 4, 0],
    effect: '「强攻组件」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'MRM-01'
  },
  {
    id: 'moonrock-mild', name: '月壤摩咔（淡）', en: 'MOONROCK MOCHACCINO · MILD',
    group: 'moonrock', accent: '#cfc2ff', liquid: '#9a8ade', garnish: 'moon',
    variant: '淡', era: 'classic', battery: 60, price: 2500, days: [2, 5, 0],
    effect: '「击破组件」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'MRM-02'
  },
  {
    id: 'moonrock-dark', name: '月壤摩咔（浓）', en: 'MOONROCK MOCHACCINO · DARK',
    group: 'moonrock', accent: '#9b86f2', liquid: '#5b47a8', garnish: 'moon',
    variant: '浓', era: 'classic', battery: 60, price: 2500, days: [2, 5, 0],
    effect: '「异常组件」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'MRM-03'
  },
  {
    id: 'bubble-mocha', name: '空泡摩咔', en: 'MOCHACCINO',
    group: 'bubble', accent: '#55e6ff', liquid: '#2f9fb8', garnish: 'bubble',
    variant: '', era: 'classic', battery: 60, price: 2500, days: [3, 6, 0],
    effect: '「支援组件」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'MOC-01'
  },
  {
    id: 'bubble-mocha-mild', name: '空泡摩咔（淡）', en: 'MOCHACCINO · MILD',
    group: 'bubble', accent: '#8befff', liquid: '#5ec6da', garnish: 'bubble',
    variant: '淡', era: 'classic', battery: 60, price: 2500, days: [1, 4, 0],
    effect: '「防护组件」掉落 +100%', scope: '仅实战模拟室 · 增益 1 张怪物卡',
    art: 'mocha', code: 'MOC-02'
  }
];

const state = {
  filter: 'all',
  selectedId: null,
  claimed: false
};

const dayOverride = (() => {
  const v = new URLSearchParams(location.search).get('day');
  if (v === null || v === '') return null;
  const n = Number(v);
  return Number.isInteger(n) && n >= 0 && n <= 6 ? n : null;
})();

const today = dayOverride === null ? new Date().getDay() : dayOverride;
const isDemoDay = dayOverride !== null;

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

/* ---------------- helpers ---------------- */

function shade(hex, percent) {
  const n = parseInt(hex.replace('#', ''), 16);
  const amt = Math.round(2.55 * percent);
  const r = Math.max(0, Math.min(255, (n >> 16) + amt));
  const g = Math.max(0, Math.min(255, ((n >> 8) & 0xff) + amt));
  const b = Math.max(0, Math.min(255, (n & 0xff) + amt));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

function rgba(hex, alpha) {
  const n = parseInt(hex.replace('#', ''), 16);
  return `rgba(${n >> 16}, ${(n >> 8) & 0xff}, ${n & 0xff}, ${alpha})`;
}

function priceText(item) {
  return item.price === 0 ? '免费' : `${item.price.toLocaleString('en-US')} 丁尼`;
}

function priceShort(item) {
  return item.price === 0 ? '0 丁尼' : `${item.price.toLocaleString('en-US')} 丁尼`;
}

function isAvailable(item) {
  if (!item.days.length) return true;
  return today === 0 || item.days.includes(today);
}

function dayList(item) {
  if (!item.days.length) return '每日';
  return item.days.map(d => DAY_CN[d]).join(' / ');
}

function effectHTML(item) {
  return item.effect.replace('+100%', '<em>+100%</em>');
}

function pad2(n) { return String(n).padStart(2, '0'); }

/* ---------------- SVG illustration ---------------- */

let svgUid = 0;

function glyphSVG(kind, color = '#0a0c09') {
  switch (kind) {
    case 'star':
      return `<path d="M0-11 3.1-4.2 10.5-3.3 5.1 1.6 6.4 8.9 0 5.3-6.4 8.9-5.1 1.6-10.5-3.3-3.1-4.2Z" fill="${color}"/>`;
    case 'leaf':
      return `<path d="M-8 6C-10-4-1-9 7-11 9-2 3 6-8 6Z" fill="${color}"/><path d="M-6 5 5-7" stroke="${rgba('#ffffff', 0.35)}" stroke-width="1.2"/>`;
    case 'fruit':
      return `<circle cx="-5" cy="3" r="4.2" fill="${color}"/><circle cx="5" cy="-1" r="3.6" fill="${color}"/><circle cx="2" cy="6" r="2.8" fill="${color}"/>`;
    case 'grass':
      return `<path d="M-8 8C-9 0-6-7-3-10M0 8C0-2 1-7 3-11M7 8C9 0 8-5 7-9" stroke="${color}" stroke-width="2.1" fill="none" stroke-linecap="round"/>`;
    case 'pepper':
      return `<circle cx="-5" cy="-3" r="2.2" fill="${color}"/><circle cx="4" cy="-5" r="1.7" fill="${color}"/><circle cx="1" cy="3" r="2.4" fill="${color}"/><circle cx="-6" cy="5" r="1.5" fill="${color}"/><circle cx="7" cy="3" r="1.8" fill="${color}"/>`;
    case 'moon':
      return `<path d="M4-10A10 10 0 1 0 10 4 8 8 0 0 1 4-10Z" fill="${color}"/><path d="M9-8 10-5 13-4 10-3 9 0 8-3 5-4 8-5Z" fill="${color}" opacity=".55"/>`;
    case 'bubble':
      return `<circle cx="-5" cy="2" r="4.5" fill="none" stroke="${color}" stroke-width="1.8"/><circle cx="5" cy="-4" r="3" fill="none" stroke="${color}" stroke-width="1.8"/><circle cx="5" cy="5" r="2" fill="${color}"/>`;
    case 'crema':
      return `<path d="M-8 4C-6-4 3-7 8-2 12 2 6 7 1 5-3 4-4 0-1-1" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round"/>`;
    default:
      return `<circle r="5" fill="${color}"/>`;
  }
}

function garnishInCup(kind, accent, variant) {
  const dark = rgba('#0a0c09', 0.55);
  const light = rgba('#ffffff', variant === '淡' ? 0.55 : 0.35);
  switch (kind) {
    case 'leaf':
      return `<g transform="translate(88 108) rotate(-18)"><path d="M-9 6C-11-4-2-10 8-12 10-2 3 6-9 6Z" fill="${accent}" opacity=".75"/><path d="M-7 5 6-8" stroke="${dark}" stroke-width="1.2"/></g>`;
    case 'fruit':
      return `<circle cx="87" cy="108" r="4.5" fill="${light}"/><circle cx="101" cy="101" r="3.2" fill="${light}"/><circle cx="110" cy="112" r="5" fill="${accent}" opacity=".8"/><circle cx="94" cy="118" r="2.4" fill="${light}"/>`;
    case 'grass':
      return `<g transform="translate(100 112)" stroke="${accent}" stroke-width="2" fill="none" stroke-linecap="round"><path d="M-8 8C-9 0-6-7-3-10M0 8C0-2 1-7 3-11M7 8C9 0 8-5 7-9"/></g>`;
    case 'pepper':
      return `<circle cx="86" cy="104" r="2" fill="${dark}"/><circle cx="98" cy="100" r="1.6" fill="${dark}"/><circle cx="109" cy="106" r="2.2" fill="${dark}"/><circle cx="92" cy="116" r="1.7" fill="${dark}"/><circle cx="105" cy="119" r="2" fill="${dark}"/>`;
    case 'moon':
      return `<g transform="translate(100 112)"><path d="M3-10A10 10 0 1 0 10 3 8 8 0 0 1 3-10Z" fill="${light}"/><circle cx="-9" cy="-6" r="1.4" fill="${light}"/><circle cx="11" cy="-8" r="1" fill="${light}"/><circle cx="9" cy="10" r="1.2" fill="${light}"/></g>`;
    case 'bubble':
      return `<g stroke="${light}" fill="none" stroke-width="1.4"><circle cx="85" cy="112" r="4.5"/><circle cx="97" cy="103" r="3"/><circle cx="108" cy="111" r="5"/><circle cx="100" cy="121" r="2.4"/><circle cx="115" cy="100" r="1.8"/></g>`;
    case 'crema':
      return `<path d="M82 108c5-8 14-9 20-4s11 4 14 0" fill="none" stroke="${light}" stroke-width="2" stroke-linecap="round"/>`;
    default:
      return '';
  }
}

function cupSVG(item, mode = 'card') {
  const uid = `u${++svgUid}`;
  const a = item.accent;
  const liquid = item.liquid || a;
  const light = shade(liquid, 22);
  const dark = shade(liquid, -22);
  const variantAlpha = item.variant === '淡' ? 0.62 : item.variant === '浓' ? 1 : 0.86;
  const creamH = item.variant === '淡' ? 25 : 17;
  const glyph = glyphSVG(item.garnish);

  const steam = `
    <g class="steam" fill="none" stroke="${a}" stroke-width="2.2" stroke-linecap="round" opacity=".75">
      <path d="M79 46c-7-9 7-13 0-22s6-11 0-17"/>
      <path d="M101 42c-7-9 7-13 0-22s6-11 0-17"/>
      <path d="M123 46c-7-9 7-13 0-22s6-11 0-17"/>
    </g>`;

  const shadow = `<ellipse cx="100" cy="196" rx="48" ry="7" fill="rgba(0,0,0,.52)"/>`;
  const badge = `
    <g transform="translate(150 92) rotate(8)">
      <circle r="18" fill="${a}"/>
      <circle r="18" fill="none" stroke="rgba(10,12,9,.35)" stroke-width="1.2" stroke-dasharray="2 3"/>
      <g transform="translate(0 0)">${glyph}</g>
    </g>`;

  if (item.art === 'espresso') {
    return `
    <svg viewBox="0 0 200 220" role="img" aria-label="${item.name} 插画">
      <defs>
        <linearGradient id="esp-${uid}" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="${light}"/>
          <stop offset=".5" stop-color="${liquid}"/>
          <stop offset="1" stop-color="${dark}"/>
        </linearGradient>
      </defs>
      ${shadow}
      ${steam}
      <ellipse cx="100" cy="190" rx="60" ry="10" fill="none" stroke="#d9dfcb" stroke-width="2.2" opacity=".85"/>
      <ellipse cx="100" cy="188" rx="45" ry="6" fill="rgba(0,0,0,.35)"/>
      <path d="M146 112h7a17 17 0 0 1 0 34h-9" fill="none" stroke="#e8ecd9" stroke-width="2.6"/>
      <path d="M52 102h96l-10 64q-2 15-16 15H78q-14 0-16-15Z" fill="#12150f" stroke="#e8ecd9" stroke-width="2.6"/>
      <ellipse cx="100" cy="104" rx="48" ry="8" fill="#e8ecd9"/>
      <ellipse cx="100" cy="104" rx="42" ry="6" fill="url(#esp-${uid})"/>
      <path d="M76 104c7-5 13 4 21 0s14 5 21 0" fill="none" stroke="rgba(255,255,255,.35)" stroke-width="1.6"/>
      <path d="M80 144h40" stroke="${a}" stroke-width="1.2" opacity=".55" stroke-dasharray="3 4"/>
      <text x="100" y="160" text-anchor="middle" font-family="monospace" font-size="7.5" letter-spacing="2.2" fill="${a}">ESPRESSO</text>
      ${badge}
      <g transform="translate(54 66) rotate(-8)" fill="${a}" opacity=".7">
        <path d="M0-5 1.5-1.5 5 0 1.5 1.5 0 5-1.5 1.5-5 0-1.5-1.5Z"/>
      </g>
    </svg>`;
  }

  const signatureExtras = item.art === 'signature' ? `
    <g opacity=".85">
      <path d="M76 44 82 30 93 38 100 24 107 38 118 30 124 44Z" fill="${a}"/>
      <path d="M44 120 52 114 50 124 42 130Z" fill="${a}" opacity=".7"/>
      <path d="M158 140 166 134 164 144 156 150Z" fill="${a}" opacity=".55"/>
    </g>` : '';

  return `
  <svg viewBox="0 0 200 220" role="img" aria-label="${item.name} 插画">
    <defs>
      <linearGradient id="liq-${uid}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="${light}"/>
        <stop offset=".46" stop-color="${liquid}"/>
        <stop offset="1" stop-color="${dark}"/>
      </linearGradient>
      <clipPath id="win-${uid}">
        <rect x="70" y="84" width="60" height="76" rx="14"/>
      </clipPath>
    </defs>
    ${shadow}
    ${steam}
    ${signatureExtras}
    <path d="M56 66H144L136 177Q135 190 122 190H78Q65 190 64 177Z"
          fill="#10130d" stroke="#e8ecd9" stroke-width="2.6"/>
    <path d="M62 76h76l-1 8H63Z" fill="rgba(255,255,255,.1)"/>
    <g clip-path="url(#win-${uid})">
      <rect x="70" y="84" width="60" height="76" fill="url(#liq-${uid})" opacity="${variantAlpha}"/>
      <rect x="70" y="84" width="60" height="${creamH}" fill="#f4e6c6" opacity="${item.variant === '淡' ? 0.9 : 0.66}"/>
      <path d="M70 ${84 + creamH}c8-5 14 5 22 0s16 5 24 0 10 3 14 1" fill="none" stroke="rgba(255,255,255,.5)" stroke-width="1.4"/>
      ${garnishInCup(item.garnish, a, item.variant)}
      <path d="M74 150h52" stroke="rgba(255,255,255,.14)" stroke-width="1"/>
    </g>
    <rect x="70" y="84" width="60" height="76" rx="14" fill="none" stroke="rgba(255,255,255,.32)" stroke-width="1.3"/>
    <path d="M61 124h78l-3 37H64Z" fill="#0b0e09" opacity=".62"/>
    <path d="M61 124h78M64 161h75" stroke="${a}" stroke-width="1" opacity=".75"/>
    <text x="100" y="141" text-anchor="middle" font-family="monospace" font-size="7.6" letter-spacing="1.9" fill="${a}">COFF CAFE</text>
    <text x="100" y="152" text-anchor="middle" font-family="monospace" font-size="5.6" letter-spacing="1.5" fill="rgba(242,244,233,.5)">NEW ERIDU</text>
    <rect x="48" y="50" width="104" height="17" rx="8.5" fill="#eef2df"/>
    <rect x="58" y="42" width="84" height="10" rx="5" fill="#c9d0b8"/>
    <rect x="92" y="38" width="16" height="6" rx="3" fill="${a}"/>
    <path d="M66 58h68" stroke="rgba(10,12,9,.18)" stroke-width="1"/>
    ${item.variant ? `<g transform="translate(100 178)"><rect x="-18" y="-5" width="36" height="10" rx="3" fill="${a}"/><text x="0" y="2.2" text-anchor="middle" font-family="monospace" font-size="6.6" font-weight="700" fill="#0a0c09">${item.variant === '淡' ? 'MILD' : 'DARK'}</text></g>` : ''}
    ${badge}
  </svg>`;
}

/* ---------------- render ---------------- */

function renderRail() {
  const rail = $('#railList');
  rail.innerHTML = Object.entries(GROUPS).map(([key, g]) => {
    const count = key === 'all' ? MENU.length : MENU.filter(i => i.group === key).length;
    return `
      <button class="rail-btn ${state.filter === key ? 'is-active' : ''}" type="button"
              data-filter="${key}" aria-pressed="${state.filter === key}">
        <span class="rail-cn">${g.cn}</span>
        <span class="rail-en">${g.en}</span>
        <span class="rail-count">${pad2(count)}</span>
      </button>`;
  }).join('');
}

function dayChips(item) {
  if (!item.days.length) {
    return `<span class="day-chip is-today">DAILY</span>`;
  }
  return item.days.map(d => {
    const isToday = today === 0 || d === today;
    return `<span class="day-chip ${isToday ? 'is-today' : ''}">${DAY_SHORT[d]}</span>`;
  }).join('');
}

function cardHTML(item, index) {
  const available = isAvailable(item);
  const selected = state.selectedId === item.id;
  const price = priceText(item);
  return `
    <article class="coffee-card ${selected ? 'is-selected' : ''} ${available ? '' : 'is-off'}"
             data-id="${item.id}" data-index="${pad2(index + 1)}" style="--accent:${item.accent}"
             aria-label="${item.name}">
      <div class="card-top">
        <span class="group-tag">${GROUPS[item.group].cn}</span>
        ${item.variant ? `<span class="variant-tag">${item.variant}</span>` : ''}
        <span class="era-tag ${item.era === 'now' ? 'is-now' : ''}">${item.era === 'now' ? '现售' : '经典'}</span>
        <span class="price-tag ${item.price === 0 ? 'is-free' : ''}">${price}</span>
      </div>
      <div class="card-art">
        ${cupSVG(item)}
        <span class="art-code">${item.code}</span>
        ${item.variant ? `<span class="variant-flag">${item.variant === '淡' ? 'MILD' : 'DARK'}</span>` : ''}
      </div>
      <div class="card-body">
        <h3>${item.name}</h3>
        <p class="card-en">${item.en}</p>
        <div class="effect-box">
          <span class="effect-mark" aria-hidden="true">◆</span>
          <span>${effectHTML(item)}<small>${item.scope}</small></span>
        </div>
        <div class="card-foot">
          <div class="days">${dayChips(item)}</div>
          <span class="battery-pill">+${item.battery} 电量</span>
        </div>
        <button class="select-btn" type="button" data-select="${item.id}"
                ${available ? '' : 'disabled'} ${selected ? 'aria-pressed="true"' : ''}>
          ${available ? (selected ? '已选择' : '选择这杯') : '本日休止'}
        </button>
      </div>
      ${available ? '' : '<span class="off-stamp">本日休止</span>'}
    </article>`;
}

function renderCards(animate = false) {
  const grid = $('#menuGrid');
  const list = state.filter === 'all' ? MENU : MENU.filter(i => i.group === state.filter);
  grid.innerHTML = list.map((item, i) => cardHTML(item, MENU.indexOf(item))).join('');
  grid.classList.toggle('is-filtering', animate);
  if (animate) {
    setTimeout(() => grid.classList.remove('is-filtering'), 500);
  }
  $('#menuEmpty').hidden = list.length !== 0;
  $('#resultCount').textContent = list.length;
  const group = GROUPS[state.filter];
  $('#filterTag').textContent = `${group.en} · ${group.cn}`;
  updateAvailabilityUI();
}

function syncSelection() {
  $$('.coffee-card').forEach(card => {
    const selected = card.dataset.id === state.selectedId;
    card.classList.toggle('is-selected', selected);
    const btn = $('.select-btn', card);
    if (!btn || btn.disabled) return;
    btn.textContent = selected ? '已选择' : '选择这杯';
    btn.setAttribute('aria-pressed', String(selected));
  });
}

function updateAvailabilityUI() {
  const avail = MENU.filter(isAvailable).length;
  $('#availCount').textContent = avail;
  const chip = $('#dateChip');
  const dayLabel = DAY_SHORT[today];
  chip.textContent = today === 0 ? `${dayLabel} · 全部供应` : `${dayLabel} · 今日供应 ${avail} 款`;
  if (isDemoDay) chip.textContent += ' · DEMO';
}

function updateOrder() {
  const item = MENU.find(i => i.id === state.selectedId);
  const order = $('#order');
  const empty = $('#orderEmpty');
  const filled = $('#orderFilled');
  const claimed = $('#orderClaimed');

  $('#quota').textContent = state.claimed ? '1 / 1' : (item ? '1 / 1' : '0 / 1');
  $('#quota').classList.toggle('is-full', Boolean(item) || state.claimed);
  $('#bagCount').textContent = state.claimed || item ? '1' : '0';

  if (state.claimed) {
    empty.hidden = true;
    filled.hidden = true;
    claimed.hidden = false;
    $('#claimedName').textContent = item ? `${item.name} · +${item.battery} 电量` : '';
    return;
  }

  claimed.hidden = true;

  if (!item) {
    empty.hidden = false;
    filled.hidden = true;
    order.style.removeProperty('--order-accent');
    return;
  }

  empty.hidden = true;
  filled.hidden = false;
  order.style.setProperty('--order-accent', item.accent);
  $('#orderThumb').innerHTML = cupSVG(item);
  $('#orderName').textContent = item.name;
  $('#orderEn').textContent = item.en;
  $('#orderVariant').textContent = item.variant ? `${item.variant}版` : (item.era === 'now' ? '现售常驻' : '经典轮换');
  $('#orderEffect').innerHTML = `${effectHTML(item)} <span style="color:var(--muted-2)">/ ${item.scope}</span>`;
  $('#orderPrice').textContent = priceText(item);
  $('#orderBattery').textContent = `+${item.battery}`;
  $('#orderDays').textContent = dayList(item);
  $('#orderTotal').innerHTML = `${priceShort(item)} <small>${item.battery} 电量</small>`;
}

function updateMobile() {
  const item = MENU.find(i => i.id === state.selectedId);
  $('#mobileName').textContent = state.claimed ? '今日咖啡已领取' : item ? item.name : '尚未选择';
  $('#mobileBtn').innerHTML = state.claimed ? '查看点单 <span aria-hidden="true">→</span>' : '去点单 <span aria-hidden="true">→</span>';
}

/* ---------------- interactions ---------------- */

let toastTimer = null;
function toast(message) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('is-show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('is-show'), 2800);
}

function selectItem(id) {
  if (state.claimed) {
    toast('今日咖啡已领取，请先重置演示');
    return;
  }
  const item = MENU.find(i => i.id === id);
  if (!item) return;
  if (!isAvailable(item)) {
    toast(`「${item.name}」本日休止 · ${dayList(item)}供应`);
    return;
  }
  const replaced = state.selectedId && state.selectedId !== id;
  state.selectedId = id;
  syncSelection();
  updateOrder();
  updateMobile();
  toast(replaced ? `已更换为「${item.name}」· 每日限饮 1 杯` : `已选择「${item.name}」· 每日限饮 1 杯`);
}

function openModal() {
  const modal = $('#modal');
  modal.hidden = false;
  document.body.classList.add('modal-open');
  const focusTarget = $('.modal-close', modal);
  if (focusTarget) focusTarget.focus({ preventScroll: true });
}

function closeModal() {
  const modal = $('#modal');
  modal.hidden = true;
  document.body.classList.remove('modal-open');
}

function fillReceipt(item) {
  const now = new Date();
  const dateStr = `${now.getFullYear()}.${pad2(now.getMonth() + 1)}.${pad2(now.getDate())}`;
  const timeStr = `${pad2(now.getHours())}:${pad2(now.getMinutes())}`;
  const seq = `${pad2(now.getMonth() + 1)}${pad2(now.getDate())}`;
  $('#rNo').textContent = `NE-${seq}-001`;
  $('#rName').textContent = item.name;
  $('#rBattery').textContent = `+${item.battery}`;
  $('#rPrice').textContent = priceText(item);
  $('#rTime').textContent = `${dateStr} ${timeStr}`;
  $('#rTotal').textContent = priceShort(item);
}

function confirmOrder() {
  const item = MENU.find(i => i.id === state.selectedId);
  if (!item || state.claimed) return;
  state.claimed = true;
  fillReceipt(item);
  updateOrder();
  updateMobile();
  openModal();
  toast('点单成功 · 今日配额已用完');
}

function resetDemo() {
  state.claimed = false;
  state.selectedId = null;
  syncSelection();
  updateOrder();
  updateMobile();
  toast('演示已重置 · 今日配额恢复 1 / 1');
}

function setDateLabels() {
  const now = new Date();
  const label = `${now.getFullYear()}.${pad2(now.getMonth() + 1)}.${pad2(now.getDate())} ${DAY_SHORT[today]}`;
  $('#tickerDate').textContent = label;
  $('#tickerDate2').textContent = label;
}

/* ---------------- bind ---------------- */

function bind() {
  $('#railList').addEventListener('click', (e) => {
    const btn = e.target.closest('.rail-btn');
    if (!btn) return;
    state.filter = btn.dataset.filter;
    $$('.rail-btn').forEach(b => {
      const active = b.dataset.filter === state.filter;
      b.classList.toggle('is-active', active);
      b.setAttribute('aria-pressed', String(active));
    });
    renderCards(true);
  });

  $('#menuGrid').addEventListener('click', (e) => {
    const btn = e.target.closest('.select-btn');
    if (btn && !btn.disabled) selectItem(btn.dataset.select);
  });

  $('#orderBtn').addEventListener('click', confirmOrder);
  $('#resetBtn').addEventListener('click', resetDemo);

  $('#bagBtn').addEventListener('click', () => {
    $('#order').scrollIntoView({ behavior: 'smooth', block: 'center' });
  });

  $('#mobileBtn').addEventListener('click', () => {
    $('#order').scrollIntoView({ behavior: 'smooth', block: 'center' });
  });

  $('#modal').addEventListener('click', (e) => {
    if (e.target.closest('[data-close]')) closeModal();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !$('#modal').hidden) closeModal();
  });
}

function init() {
  setDateLabels();
  renderRail();
  renderCards(false);
  updateOrder();
  updateMobile();
  $('#heroArt').innerHTML = cupSVG(MENU[0]);
  bind();
}

init();
